function schoolChanged(e) {
	settings.school = e.target.selectedOptions[0].value;
}

function classChanged(e) {
	settings.class = e.target.value;
}
